/*
NinthStar - A portable Win32 NES Emulator written in C++
Copyright (C) 2000  David de Regt

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

For a copy of the GNU General Public License, go to:
http://www.gnu.org/copyleft/gpl.html#SEC1
*/

// Very -=VERY=- Messy...  Going to need to be rewritten but I just wanted to make
// Akilla happy.  Hi2u Akilla :PPP

// Azimer
//
// History:
// ------------------------------------------------------------------------------------
// Dec. 17th	-	BASIC Pulse Waves #1 and #2 completed (sounds pretty nice actually)

#include "stdafx.h"

#include <stdio.h> // Needed for debugging information...

#include "NES_APU.h"
#include "..\NinthStar.h"

cNES_APU *APU;

#define FREQ		44100
#define SEGMENTS	4
#define LOCK_SIZE	(FREQ / 60) // Always 8bit mono (For the time being...)

DWORD WINAPI SoundProc(void) {
	int last_pos = 0, write_pos = 0, play_pos = 0, temp = 0;
	LPVOID lpvPtr1, lpvPtr2;
	DWORD dwBytes1, dwBytes2;
	HRESULT hr;
	LPDIRECTSOUNDBUFFER8 lpdsb = APU->lpdsb;
	LPDIRECTSOUND		 lpds  = APU->lpds;
	volatile bool *bufferInUse	= &APU->bufferInUse;
	BYTE *buffer		= APU->buffer;

	if (lpds == NULL) {
		APU->hThread = NULL;
		ExitThread(0);
		return -1;
	}

	hr = lpdsb->Lock (0, LOCK_SIZE, &lpvPtr1, &dwBytes1, &lpvPtr2, &dwBytes2, DSBLOCK_ENTIREBUFFER);
	if (hr != DS_OK) {
		MessageBox (NULL, "Error locking sound buffer (Clear)","NinthStar", MB_OK|MB_ICONSTOP);
		goto _exit_;
	}

	ZeroMemory (lpvPtr1, dwBytes1);

	if FAILED(lpdsb->Unlock(lpvPtr1, dwBytes1, lpvPtr2, dwBytes2)) {
		MessageBox(NULL, "Error unlocking sound buffer","NinthStar", MB_OK|MB_ICONSTOP);
		goto _exit_;
	}

	lpdsb->Play (0, 0, DSBPLAY_LOOPING);

	while (APU->isEnabled) {

		last_pos = write_pos;

		while (last_pos == write_pos) {

			if FAILED(lpdsb->GetCurrentPosition((unsigned long*)&play_pos, NULL)) {
				MessageBox(NULL, "Error getting audio position", "NinthStar", MB_OK|MB_ICONSTOP);
				goto _exit_;
			}

			if (!APU->isEnabled) goto _exit_;	/* infinite loop */

			if (play_pos < LOCK_SIZE) write_pos = (LOCK_SIZE * SEGMENTS) - LOCK_SIZE;
			else write_pos = ((play_pos / LOCK_SIZE) * LOCK_SIZE) - LOCK_SIZE;
			
			if (write_pos == last_pos) Sleep(1);
		}

		last_pos = write_pos;

		while (*bufferInUse == true);

		if (DS_OK != lpdsb->Lock(write_pos, LOCK_SIZE, &lpvPtr1, &dwBytes1, &lpvPtr2, &dwBytes2, 0)) {
			MessageBox(NULL, "Error locking sound buffer","NinthStar", MB_OK|MB_ICONSTOP);
			goto _exit_;
		}

		memcpy (lpvPtr1, buffer, dwBytes1);

		if FAILED(lpdsb->Unlock(lpvPtr1, dwBytes1, lpvPtr2, dwBytes2)) {
			MessageBox(NULL, "Error unlocking sound buffer","NinthStar", MB_OK|MB_ICONSTOP);
			goto _exit_;
		}
		Sleep (5);
	}

_exit_:
	lpdsb->Stop ();

	APU->hThread = NULL;

	ExitThread(0);

	return 0;
}

	
cNES_APU::cNES_APU(HWND hWnd) {
	HRESULT hr;
	WAVEFORMATEX wfx;

	APU			= this;
	isEnabled	= false;
	hThread		= NULL;
	dwThreadId	= 0;
	WantFPS		= 60;
	
	ZeroMemory (&wfx, sizeof(WAVEFORMATEX)); 
    wfx.wFormatTag = WAVE_FORMAT_PCM;
	wfx.nChannels = 1; 
    wfx.nSamplesPerSec = FREQ;//22050;     
	wfx.wBitsPerSample = 8; 
    wfx.nBlockAlign = wfx.wBitsPerSample / 8 * wfx.nChannels;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;

	ZeroMemory (&dsbdesc, sizeof(DSBUFFERDESC));
    dsbdesc.dwSize = sizeof(DSBUFFERDESC);
    dsbdesc.dwFlags = DSBCAPS_GETCURRENTPOSITION2   // Always a good idea
					| DSBCAPS_GLOBALFOCUS;          // Allows background playing
	dsbdesc.dwBufferBytes = (LOCK_SIZE * SEGMENTS);
	dsbdesc.lpwfxFormat = &wfx;

	hr = DirectSoundCreate8 (&DSDEVID_DefaultPlayback,
							 &lpds,
							 NULL);
	if (hr == DS_OK) {
		hr = lpds->SetCooperativeLevel (hWnd,
										DSSCL_PRIORITY);
		if (hr == DS_OK) {
			hr = lpds->CreateSoundBuffer   (&dsbdesc, 
											&lpdsbuff, 
											NULL);
			if (hr == DS_OK) {
				hr = lpdsbuff->QueryInterface (IID_IDirectSoundBuffer8, (LPVOID *)&lpdsb);
				if (hr == S_OK) {
					isEnabled = true;
				} else {
					isEnabled = false;
					lpdsbuff->Release ();
					lpds->Release();
					MessageBox (hWnd, "Failed to Query Sound Buffer for DS8 Interface", "NinthStar", MB_OK);
				}
			} else {
				isEnabled = false;
				lpds->Release();
				MessageBox (hWnd, "Failed to Create DirectSound Buffer", "NinthStar", MB_OK);
			}
		} else {
			MessageBox (hWnd, "Failed to Set Cooperative Mode", "NinthStar", MB_OK);
			lpds->Release();
		}
	} else {
		MessageBox (hWnd, "Failed to Create DirectSound Object", "NinthStar", MB_OK);
	}
	buffer = (BYTE *)malloc (LOCK_SIZE);
}

cNES_APU::~cNES_APU() {
	free (buffer);
	isEnabled = false;
	while (APU->hThread != NULL)
		Sleep(10); // This can be dangerous... but really shouldn't be
	if (lpdsb)
		lpdsb->Release ();
	if (lpdsbuff)
		lpdsbuff->Release ();
	if (lpds)
		lpds->Release ();
}

void cNES_APU::Write4000 (unsigned char Val) {     // Write done to Register $4000
	pWidth[0] = Val >> 6;
	pToneData[0] = Val & 0xf;
}
void cNES_APU::Write4001 (unsigned char Val) {     // Write done to Register $4001
}
void cNES_APU::Write4002 (unsigned char Val) {     // Write done to Register $4002	
	pFrequency[0] = (((((WORD)Regs[3] & 0x07) << 8) + 1) + Regs[2]) << 1;
}
void cNES_APU::Write4003 (unsigned char Val) {     // Write done to Register $4003
	pFrequency[0] = (((((WORD)Regs[3] & 0x07) << 8) + 1) + Regs[2]) << 1;
}
void cNES_APU::Write4004 (unsigned char Val) {     // Write done to Register $4004
	pWidth[1] = Val >> 6;
	pToneData[1] = Val & 0xf;
}
void cNES_APU::Write4005 (unsigned char Val) {     // Write done to Register $4005
}
void cNES_APU::Write4006 (unsigned char Val) {     // Write done to Register $4006
	pFrequency[1] = (((((WORD)Regs[7] & 0x07) << 8) + 1) + Regs[6]) << 1;
}
void cNES_APU::Write4007 (unsigned char Val) {     // Write done to Register $4007
	pFrequency[1] = (((((WORD)Regs[7] & 0x07) << 8) + 1) + Regs[6]) << 1;
}
void cNES_APU::Write4008 (unsigned char Val) {     // Write done to Register $4008
}
void cNES_APU::Write4009 (unsigned char Val) {     // Write done to Register $4009
}
void cNES_APU::Write400A (unsigned char Val) {     // Write done to Register $400A
}
void cNES_APU::Write400B (unsigned char Val) {     // Write done to Register $400B
}
void cNES_APU::Write400C (unsigned char Val) {     // Write done to Register $400C
}
void cNES_APU::Write400D (unsigned char Val) {     // Write done to Register $400D
}
void cNES_APU::Write400E (unsigned char Val) {     // Write done to Register $400E
}
void cNES_APU::Write400F (unsigned char Val) {     // Write done to Register $400F
}
void cNES_APU::Write4010 (unsigned char Val) {     // Write done to Register $4010
}
void cNES_APU::Write4011 (unsigned char Val) {     // Write done to Register $4011
}
void cNES_APU::Write4012 (unsigned char Val) {     // Write done to Register $4012
}
void cNES_APU::Write4013 (unsigned char Val) {     // Write done to Register $4013
}
void cNES_APU::Write4015 (unsigned char Val) {     // Write done to Register $4015
	if (Val & 0x1)
		pEnabled[0] = true;
	else
		pEnabled[0] = false;
	if (Val & 0x2)
		pEnabled[1] = true;
	else
		pEnabled[1] = false;
}
BYTE cNES_APU::Read4015  () {     // Read  done to Register $4015
	return 0;
}

void cNES_APU::Reset  (void) { // Resets the sound registers
	ZeroMemory (&Regs[0], 0x16);
	wavcount	 = 0.0;
	pFrequency[0]= pFrequency[1]= 0;
	pToneData[0] = pToneData[1] = 0;
	pWidth	 [0] = pWidth	[1] = 0;
	pCycles  [0] = pCycles  [1] = 0.0;
	pBitSet  [0] = pBitSet  [1] = 0;
	pBit     [0] = pBit     [1] = 0;
	pEnvelope[0] = pEnvelope[1] = 0;
	pVolsqr  [0] = pVolsqr  [1] = 0;
	pEnvCnt  [0] = pEnvCnt  [1] = 0;
	pEnabled [0] = pEnabled [1] = 0;
	pLength  [0] = pLength  [1] = 0;
}

void cNES_APU::SoundOFF (void) {	// Turns the sound off ( ROM Close )
	isEnabled = false;
}

void cNES_APU::SoundON  (void) { // Turns the sound on  ( ROM Open  )
	isEnabled = true;
	hThread = CreateThread (NULL, NULL, (LPTHREAD_START_ROUTINE)SoundProc, NULL, NULL, (DWORD *)&dwThreadId);
}

void cNES_APU::Config(HWND hWNd, HINSTANCE hInstance) {
}

void cNES_APU::GetSoundRegisters(unsigned char * StoreHere) {
	memcpy (StoreHere, Regs, 0x16);
}

void cNES_APU::SetSoundRegisters(unsigned char GetFromHere[0x16]) {
	memcpy (Regs, GetFromHere, 0x16);
	//lelel
}

//#define numpasses 1

double nessndbase = 3579545.45454545 / 2.0;
#define numcycwav  (FREQ/60) // Assuming 44100Hz for the time being
#define nesincsize ((nessndbase / 60) / numcycwav)
double nummsframe = 1000 / FREQ;
//double nummsframe = 1000 / FREQ*numpasses;//44100;
int Width[4] = {2, 4, 6, 7}; //25, 50, 75, 87.5
byte duties[4][8] = {
	{1, 1, 1, 1, 1, 1, 1, 0}, // 87.5%
	{1, 1, 1, 1, 1, 1, 0, 0}, // 75.0%
	{1, 1, 1, 1, 0, 0, 0, 0}, // 50.0%
	{1, 1, 0, 0, 0, 0, 0, 0}  // 25.0%
};

void cNES_APU::VBlank (void) { // VBlank notifcation
	int x;
	DWORD data;
	DWORD dataindex=0;
	DWORD pregbase;

	wavcount += numcycwav;

	x = (long)wavcount;
	wavcount -= (double)x;

	const unsigned int PulseLengths[0x20] = {
		71, 2113, 157, 10, 
		330,  30, 661,  48,
		1333,  58, 489, 72, 
		113,  99, 212,  112,
		97,   122, 194, 149, 
		394, 165, 796, 183, 
		1600, 197, 597, 183, 
		131, 230, 257, 248,
	};

	//x /= numpasses;
	bufferInUse = true;
	data = 0;
	for (;x > 0; x--) {
	for (int pulse=0; pulse < 2; pulse++) {
		pregbase = (pulse << 2);
		pCycles[pulse]  -= nesincsize;
		if (pCycles[pulse] < 0) {
			pCycles[pulse] += pFrequency[pulse];
			pBitSet[pulse] = ((pBitSet[pulse]++) & 0x7);
		}
		pBit[pulse] = duties[pWidth[pulse]][pBitSet[pulse]];
		if (pEnabled[pulse] == false) pBit[pulse] = 0;
		if (Regs[0+pregbase] & 0x20) {
			pLength[pulse] = PulseLengths[(Regs[3+pregbase] >> 3)];
			if (pEnvelope[pulse] == -1)
				pEnvelope[pulse] = 15;
		} 
		if ((Regs[0+pregbase] & 0x20) == 0)
			if (pLength[pulse] < 0)
				pBit[pulse] = 0;
		if (pLength[pulse] > 0)
			pLength[pulse] -= nummsframe;
		if ((Regs[0+pregbase] & 0x10)==0)
			pVolsqr[pulse] = pEnvelope[pulse];
		else
			pVolsqr[pulse] = pToneData[pulse];

		if (pEnvCnt[pulse] < 0) {
			pEnvCnt[pulse] = pToneData[pulse] + 1;
			pEnvelope[pulse]--;
		}

		if (pEnvelope[pulse] == -2)
			pEnvelope[pulse] = -1;
		if ((Regs[0+pregbase] & 0x30)==0)
			if (pEnvelope[pulse] == -1)
				pBit[pulse] = 0;

		data += pVolsqr[pulse] * pBit[pulse];
		//if (Regs[1] & 0x80) // Putch Bend... Not supported yet...
			//data = 0;
	}
		data *= 0x7; // Add some to it for extra sound

		data = (byte)(data/2);

		//fwrite (&data, 1, 1, waveout);
		buffer[dataindex++] = (unsigned char) data;
		data=0;
	}
	bufferInUse = false;
}




void UpdateNESSound ()
{
}
