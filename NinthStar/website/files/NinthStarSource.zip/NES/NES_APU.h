/*
NinthStar - A portable Win32 NES Emulator written in C++
Copyright (C) 2000  David de Regt

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

For a copy of the GNU General Public License, go to:
http://www.gnu.org/copyleft/gpl.html#SEC1
*/

#ifndef CAPU_H
#define CAPU_H

#include <windows.h>
#include <mmsystem.h>
#include <dsound.h>
//#include "NES_Handlers.h"

class cNES_APU {
	public:
		cNES_APU           (HWND hWnd);	// Only Constructor
		~cNES_APU          ();			// Default destructor

		void GetSoundRegisters	(unsigned char * StoreHere);
		void SetSoundRegisters	(unsigned char GetFromHere[0x16]);
		void VBlank				(void); // VBlank notifcation
		void SoundOFF			(void);	// Turns the sound off ( ROM Close )
		void SoundON			(void); // Turns the sound on  ( ROM Open  )
		void Reset				(void); // Resets the sound registers
        void Config				(HWND hWNd,
								 HINSTANCE hInstance);   // Opens sound configuration dialog
		volatile bool	isEnabled;		// Tells the APU if the sound is on...
		volatile HANDLE	hThread;		// Handle to the Sound thread  
		volatile DWORD  dwThreadId;		// Sound Thread Id
		volatile bool	bufferInUse; // Buffer Flag

		LPDIRECTSOUND8			lpds;	// Direct Sound Object
		LPDIRECTSOUNDBUFFER8	lpdsb;	// Direct Sound Buffer
		LPDIRECTSOUNDBUFFER		lpdsbuff;	// 
		DSBUFFERDESC			dsbdesc; // Direct Sound Buffer Description
		BYTE					*buffer;	// Sound Buffer
		BYTE					Regs[0x16]; // Sound Registers
		double					wavcount;
		double					pLength[2];
		double					pCycles[2];
		WORD					pFrequency[2];
		BYTE					pToneData[2];
		BYTE					pWidth[2];
		BYTE					pBitSet[2];
		BYTE					pBit[2];
		BYTE					pEnvelope[2];
		BYTE					pVolsqr[2];
		BYTE					pEnvCnt[2];
		BYTE					pEnabled[2];

		unsigned char			WantFPS;

// TODO: Special Sound Hardware (VRC7, VRC6, etc)

        void Write4000 (unsigned char Val);     // Write done to Register $4000
        void Write4001 (unsigned char Val);     // Write done to Register $4001
        void Write4002 (unsigned char Val);     // Write done to Register $4002
        void Write4003 (unsigned char Val);     // Write done to Register $4003
        void Write4004 (unsigned char Val);     // Write done to Register $4004
        void Write4005 (unsigned char Val);     // Write done to Register $4005
        void Write4006 (unsigned char Val);     // Write done to Register $4006
        void Write4007 (unsigned char Val);     // Write done to Register $4007
        void Write4008 (unsigned char Val);     // Write done to Register $4008
        void Write4009 (unsigned char Val);     // Write done to Register $4009
        void Write400A (unsigned char Val);     // Write done to Register $400A
        void Write400B (unsigned char Val);     // Write done to Register $400B
        void Write400C (unsigned char Val);     // Write done to Register $400C
        void Write400D (unsigned char Val);     // Write done to Register $400D
        void Write400E (unsigned char Val);     // Write done to Register $400E
        void Write400F (unsigned char Val);     // Write done to Register $400F
        void Write4010 (unsigned char Val);     // Write done to Register $4010
        void Write4011 (unsigned char Val);     // Write done to Register $4011
        void Write4012 (unsigned char Val);     // Write done to Register $4012
        void Write4013 (unsigned char Val);     // Write done to Register $4013
        void Write4015 (unsigned char Val);     // Write done to Register $4015
        BYTE Read4015  ();     // Read  done to Register $4015

	private:
};

#endif