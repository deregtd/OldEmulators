/*
NinthStar - A portable Win32 NES Emulator written in C++
Copyright (C) 2000  David de Regt

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

For a copy of the GNU General Public License, go to:
http://www.gnu.org/copyleft/gpl.html#SEC1
*/

#include "stdafx.h"

#include "NES_PPU_Pixel.h"
#include "..\NinthStar.h"

#define		VMemory(Addy)		*(CHRPointer[(Addy & 0x1C00) >> 10] + (Addy & 0x03FF))

const unsigned char CharSC[8] = {
	0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01
};

cNES_PPU_Pixel::cNES_PPU_Pixel()
{
	StatusReg = 0;
	ZeroMemory(&CHR,sizeof(CHR));
	ZeroMemory(&CHR_RAM,sizeof(CHR_RAM));
	ZeroMemory(&Palette,sizeof(Palette));
	ZeroMemory(&Sprite,sizeof(Sprite));
	VRAMAddr = 0;
	SLnum = 0;
	IntReg = 0;
	IntX = 0;
	IntXBak = 0;
	EmphBit = 0;
	HVTog = true;
	ppuLatch = 0;
	ppuReadLatch = 0;

	for (int i=0;i<0x2000;i++)
		MType[i] = MT_CHR;
	for (i=0x2000;i<0x3000;i++)
		MType[i] = MT_NTAB;
	for (i=0x3000;i<0x3F00;i++)
		MType[i] = MT_NTABM;
	for (i=0x3F00;i<0x4000;i++)
		MType[i] = MT_PAL;
}

void cNES_PPU_Pixel::Scanline()
{
	SLnum++;
	Xnum = 0;
	if (SLnum < 240) {
		if (ControlReg[1] & 0x18)
		{
//<Hax0r>
			IntX = IntXBak;
//</Hax0r>
			VRAMAddr &= ~0x41F;					//scanline start (if background and sprites are enabled):
			VRAMAddr |= IntReg & 0x041F;		//		v:0000010000011111=t:0000010000011111
		}

		if (ControlReg[1] & 0x18)
		{
			char TPV = (VRAMAddr & 0x7000) >> 12;
			TPV++;
			if (TPV == 8)
			{
				TPV = 0;

				short tpa = ((VRAMAddr & 0x03E0)>>5) | ((VRAMAddr & 0x800) >> 6);
				tpa++;
				if ((tpa & 0x1F) == 0x1E) tpa += 2;
				VRAMAddr &= ~0x0BE0;
				VRAMAddr |= (tpa & 0x20) << 6;
				VRAMAddr |= (tpa & 0x1F) << 5;
			}
			VRAMAddr &= 0x8FFF;						//Add one row to IntY
			VRAMAddr |= TPV << 12;
		}
	}
	if (SLnum == 240)
		StatusReg &= 0xBF;		//Clear VBlank Flag + Sprite 0 Hit Flag
	if (SLnum == SLEndFrame)
	{
		StatusReg &= 0x1F;		//Clear VBlank Flag + Sprite 0 Hit Flag
		SLnum = 0;
		Sprite->SprAddr = 0;
//<Hax0r>
//		IntX &= 0xFF;
		IntX = IntXBak;
//</Hax0r>
		if (ControlReg[1] & 0x18)
			VRAMAddr = IntReg;					//		v=t
	}

	DiscoveredSprites = false;
}

void cNES_PPU_Pixel::DrawPixels(char NumPixels)
{
	short MaxX = Xnum + NumPixels;
	if (MaxX > 256) MaxX = 256;

	int i, s;
	unsigned char TSY;
	BYTE midx;
	unsigned char TpTile;
	short PatAddr, PatAddr2;
	char TC;
	BYTE AttribTableVal;
	BYTE Depth = pGFX->Depth;
	unsigned char *pThisPixel;
	bool Spr0SpriteCheck, Spr0BackCheck;
	
	if (pGFX->FPSCnt < pGFX->FSkip)
	{
		for (i=Xnum;i<MaxX;i++)
		{
			Spr0SpriteCheck = false;
			Spr0BackCheck = false;

			if (ControlReg[1] & 0x10)
			{
				for (s=((SprCount-1) << 2);s>=0;s-=4)
				{
					if ((SprBuff[s+2] & 0x20) && (SprBuff[s+3] <= i) && (SprBuff[s+3]+8 > i))
					{
						midx = i-SprBuff[s+3];
						if (SprBuff[s+2] & 0x40)
							midx = 7-midx;		//HFlip
						TSY = SprBuff[s];
						if (SprBuff[s+2] & 0x80)					//VFlip
							if (ControlReg[0] & 0x20)
								TSY = 15 - TSY;
							else
								TSY = 7 - TSY;

						TpTile = SprBuff[s+1];
						PatAddr = 0;
						if (ControlReg[0] & 0x20)
						{
							if (SprBuff[s+1] & 1)
								PatAddr |= 0x1000;
							TpTile &= 0xFE;
						} else {
							PatAddr |= ((ControlReg[0] & 0x08) << 9);
						}
						PatAddr |= ((TpTile + ((TSY & 0x8)>>3)) << 4) + (TSY & 0x07);

						if (!midx)
							if (TileHandler)
								TileHandler((PatAddr & 0x1000) >> 10, TpTile, -1);
						
						if (!(StatusReg & 0x40))
						{
							TC = (VMemory(PatAddr) & CharSC[midx]) >> (7-midx);
							TC |= ((VMemory(PatAddr+8) & CharSC[midx]) >> (7-midx)) << 1;
							if (TC)
								if ((Spr0InLine) && (s == 0))
									Spr0SpriteCheck = true;
						}
					}
				}
			}

			if (ControlReg[1] & 0x08)
			{
				PatAddr = *(CHRPointer[8+((VRAMAddr & 0xC00)>>10)] + (VRAMAddr & 0x3FF));
				PatAddr2 = (PatAddr << 4) | ((VRAMAddr & 0x7000) >> 12) | ((ControlReg[0] & 0x10) << 8);

				if (!IntX)
					if (TileHandler)
						TileHandler((PatAddr2 & 0x1000) >> 10, (unsigned char) PatAddr, VRAMAddr & 0x3FF);

				if (!(StatusReg & 0x40))
				{
					TC = (VMemory(PatAddr2) & CharSC[IntX]) >> (7-IntX);
					TC |= ((VMemory(PatAddr2+8) & CharSC[IntX]) >> (7-IntX)) << 1;
					if (TC)
						Spr0BackCheck = true;
				}
			}

			if (ControlReg[1] & 0x10)
			{
				for (s=((SprCount-1) << 2);s>=0;s-=4)
				{
					if ((!(SprBuff[s+2] & 0x20)) && (SprBuff[s+3] <= i) && (SprBuff[s+3]+8 > i))
					{
						midx = i-SprBuff[s+3];
						if (SprBuff[s+2] & 0x40)
							midx = 7-midx;		//HFlip
						TSY = SprBuff[s];
						if (SprBuff[s+2] & 0x80)					//VFlip
							if (ControlReg[0] & 0x20)
								TSY = 15 - TSY;
							else
								TSY = 7 - TSY;

						TpTile = SprBuff[s+1];
						PatAddr = 0;
						if (ControlReg[0] & 0x20)
						{
							if (SprBuff[s+1] & 1)
								PatAddr |= 0x1000;
							TpTile &= 0xFE;
						} else {
							PatAddr |= ((ControlReg[0] & 0x08) << 9);
						}
						PatAddr |= ((TpTile + ((TSY & 0x8)>>3)) << 4) + (TSY & 0x07);

						if (!midx)
							if (TileHandler)
								TileHandler((PatAddr & 0x1000) >> 10, TpTile, -1);
						
						if (!(StatusReg & 0x40))
						{
							TC = (VMemory(PatAddr) & CharSC[midx]) >> (7-midx);
							TC |= ((VMemory(PatAddr+8) & CharSC[midx]) >> (7-midx)) << 1;
							if (TC)
								if ((Spr0InLine) && (s == 0))
									Spr0SpriteCheck = true;
						}
					}
				}
			}

			if ((Spr0SpriteCheck) && (Spr0BackCheck))
				StatusReg |= 0x40;			//Sprite 0 hit

			Xnum++;

			if (ControlReg[1] & 0x18)
			{
				IntX++;
				if (IntX & 8)
				{
					IntX = 0;
					short tpa = (VRAMAddr & 0x1F) | ((VRAMAddr & 0x400)>>5);
					tpa++;
					VRAMAddr &= ~0x41F;
					VRAMAddr |= (tpa & 0x20) << 5;
					VRAMAddr |= (tpa & 0x1F);
				}
			}
		}
		return;
	}
	
//Possible Optimizations:
//
//Draw front-to-back and don't draw further back if something's already drawn.
//
	if (pGFX->Mode3D)
	{
		pThisPixel = pGFX->DrawArray + (SLnum*pGFX->Pitch) + Xnum;
	} else {
		pThisPixel = pGFX->DrawArray + (SLnum*pGFX->Pitch) + (Xnum*Depth);
	}
	for (i=Xnum;i<MaxX;i++)
	{	
		if (pGFX->Mode3D)
		{
			*pThisPixel = Palette[0][0];
		} else {
			if (pGFX->Depth == 2)
				*((unsigned short *) pThisPixel) = (unsigned short) FixedPalette[Palette[0][0]];
			else
				*((unsigned long *) pThisPixel) = FixedPalette[Palette[0][0]];
//			memcpy(pThisPixel,&FixedPalette[Palette[0][0]],Depth);
		}
		
		Spr0SpriteCheck = false;
		Spr0BackCheck = false;

		if (ControlReg[1] & 0x10)
		{
			for (s=((SprCount-1) << 2);s>=0;s-=4)
			{
				if ((SprBuff[s+2] & 0x20) && (SprBuff[s+3] <= i) && (SprBuff[s+3]+8 > i))
				{
					midx = i-SprBuff[s+3];
					if (SprBuff[s+2] & 0x40)
						midx = 7-midx;		//HFlip
					TSY = SprBuff[s];
					if (SprBuff[s+2] & 0x80)					//VFlip
						if (ControlReg[0] & 0x20)
							TSY = 15 - TSY;
						else
							TSY = 7 - TSY;

					TpTile = SprBuff[s+1];
					PatAddr = 0;
					if (ControlReg[0] & 0x20)
					{
						if (SprBuff[s+1] & 1)
							PatAddr |= 0x1000;
						TpTile &= 0xFE;
					} else {
						PatAddr |= ((ControlReg[0] & 0x08) << 9);
					}
					PatAddr |= ((TpTile + ((TSY & 0x8)>>3)) << 4) + (TSY & 0x07);

					if (!midx)
						if (TileHandler)
							TileHandler((PatAddr & 0x1000) >> 10, TpTile, -1);
					
					TC = (VMemory(PatAddr) & CharSC[midx]) >> (7-midx);
					TC |= ((VMemory(PatAddr+8) & CharSC[midx]) >> (7-midx)) << 1;
					if (TC)
					{
						TC |= (SprBuff[s + 2] & 0x03) << 2;
						if (pGFX->Mode3D)
						{
							*pThisPixel = Palette[1][TC];
						} else {
							if (pGFX->Depth == 2)
								*((unsigned short *) pThisPixel) = (unsigned short) FixedPalette[Palette[1][TC]];
							else
								*((unsigned long *) pThisPixel) = FixedPalette[Palette[1][TC]];
						}
						if ((Spr0InLine) && (s == 0))
							Spr0SpriteCheck = true;
					}
				}
			}
		}

		if (ControlReg[1] & 0x08)
		{
			PatAddr = *(CHRPointer[8+((VRAMAddr & 0xC00)>>10)] + (VRAMAddr & 0x3FF));
			PatAddr2 = (PatAddr << 4) | ((VRAMAddr & 0x7000) >> 12) | ((ControlReg[0] & 0x10) << 8);

			AttribTableVal = (*(CHRPointer[8+((VRAMAddr & 0xC00)>>10)] + (0x3C0 | ((VRAMAddr & 0x1C) >> 2) | ((VRAMAddr & 0x380) >> 4))) >> ((((VRAMAddr & 2) >> 1) | ((VRAMAddr & 0x40) >> 5)) << 1)) & 3;

			if (!IntX)
				if (TileHandler)
					TileHandler((PatAddr2 & 0x1000) >> 10, (unsigned char) PatAddr, VRAMAddr & 0x3FF);

			TC = (VMemory(PatAddr2) & CharSC[IntX]) >> (7-IntX);
			TC |= ((VMemory(PatAddr2+8) & CharSC[IntX]) >> (7-IntX)) << 1;
			if (TC)
			{
				TC |= AttribTableVal << 2;
				if (pGFX->Mode3D)
				{
					*pThisPixel = Palette[0][TC];
				} else {
					if (pGFX->Depth == 2)
						*((unsigned short *) pThisPixel) = (unsigned short) FixedPalette[Palette[0][TC]];
					else
						*((unsigned long *) pThisPixel) = FixedPalette[Palette[0][TC]];
				}
				Spr0BackCheck = true;
			}
		}

		if (ControlReg[1] & 0x10)
		{
			for (s=((SprCount-1) << 2);s>=0;s-=4)
			{
				if ((!(SprBuff[s+2] & 0x20)) && (SprBuff[s+3] <= i) && (SprBuff[s+3]+8 > i))
				{
					midx = i-SprBuff[s+3];
					if (SprBuff[s+2] & 0x40)
						midx = 7-midx;		//HFlip
					TSY = SprBuff[s];
					if (SprBuff[s+2] & 0x80)					//VFlip
						if (ControlReg[0] & 0x20)
							TSY = 15 - TSY;
						else
							TSY = 7 - TSY;

					TpTile = SprBuff[s+1];
					PatAddr = 0;
					if (ControlReg[0] & 0x20)
					{
						if (SprBuff[s+1] & 1)
							PatAddr |= 0x1000;
						TpTile &= 0xFE;
					} else {
						PatAddr |= ((ControlReg[0] & 0x08) << 9);
					}
					PatAddr |= ((TpTile + ((TSY & 0x8)>>3)) << 4) + (TSY & 0x07);

					if (!midx)
						if (TileHandler)
							TileHandler((PatAddr & 0x1000) >> 10, TpTile, -1);
					
					TC = (VMemory(PatAddr) & CharSC[midx]) >> (7-midx);
					TC |= ((VMemory(PatAddr+8) & CharSC[midx]) >> (7-midx)) << 1;
					if (TC)
					{
						TC |= (SprBuff[s + 2] & 0x03) << 2;
						if (pGFX->Mode3D)
						{
							*pThisPixel = Palette[1][TC];
						} else {
							if (pGFX->Depth == 2)
								*((unsigned short *) pThisPixel) = (unsigned short) FixedPalette[Palette[1][TC]];
							else
								*((unsigned long *) pThisPixel) = FixedPalette[Palette[1][TC]];
						}
						if ((Spr0InLine) && (s == 0))
							Spr0SpriteCheck = true;
					}
				}
			}
		}

		if ((Spr0SpriteCheck) && (Spr0BackCheck))
			StatusReg |= 0x40;			//Sprite 0 hit

		if (pGFX->Mode3D)
		{
			pThisPixel++;
		} else {
			pThisPixel += Depth;
		}

		Xnum++;
		if (ControlReg[1] & 0x18)
		{
			IntX++;
			if (IntX & 8)
			{
				IntX = 0;
				short tpa = (VRAMAddr & 0x1F) | ((VRAMAddr & 0x400)>>5);
				tpa++;
				VRAMAddr &= ~0x41F;
				VRAMAddr |= (tpa & 0x20) << 5;
				VRAMAddr |= (tpa & 0x1F);
			}
		}
	}
}

void cNES_PPU_Pixel::FrameDone()
{
	StatusReg |= 0x80;
	
	pGFX->DrawScreen();
}

void cNES_PPU_Pixel::DiscoverSprites()
{
	DiscoveredSprites = true;

	SprCount = 0;
	Spr0InLine = false;
	
	for (int spt=0;spt<64;spt++)
	{
		BYTE TB = Sprite->Sprite[spt << 2]+1;
		if ((*((unsigned long *)&Sprite->Sprite[spt << 2])) == 0)
			continue;
		if (ControlReg[0] & 0x20)
		{
			if (((TB+6+8) >= SLnum) && ((TB+6+8) < (SLnum+16)))
			{
				if (SprCount < 8)
				{
					//Optimize this somehow...
					SprBuff[SprCount << 2] = 15 - (Sprite->Sprite[spt << 2] + 7+8 - SLnum);
					SprBuff[(SprCount << 2) + 1] = Sprite->Sprite[(spt << 2)+1];
					SprBuff[(SprCount << 2) + 2] = Sprite->Sprite[(spt << 2)+2];
					SprBuff[(SprCount << 2) + 3] = Sprite->Sprite[(spt << 2)+3];
					if (spt == 0)
						Spr0InLine = true;

					SprCount++;
				}
			}
		} else {
			if ((TB+6 >= SLnum) && (TB+6 < (SLnum+8)))
			{
				if (SprCount < 8)
				{
					//Optimize this somehow...
					SprBuff[SprCount << 2] = 7 - (Sprite->Sprite[spt << 2] + 7 - SLnum);
					SprBuff[(SprCount << 2) + 1] = Sprite->Sprite[(spt << 2)+1];
					SprBuff[(SprCount << 2) + 2] = Sprite->Sprite[(spt << 2)+2];
					SprBuff[(SprCount << 2) + 3] = Sprite->Sprite[(spt << 2)+3];

					if (spt == 0)
						Spr0InLine = true;

					SprCount++;
				}
			}
		}
	}

	StatusReg &= 0xDF;
	StatusReg |= (SprCount >= 8) << 5;		//Set 8-Sprite Bit
}
